# Optional Dobby integration

The upstream Dobby project documents Android/CMake integration and exposes
`DobbyHook()` for inline function hooks. See the upstream documentation before
pinning a revision. Do not enable Android linker-restriction bypass options for
this template.

For a reproducible project, vendor a reviewed Dobby revision under
`third_party/Dobby/` and use `add_subdirectory()` rather than tracking `master`.
