Dependencies are fetched by CMake.

For reproducible/offline builds, vendor the pinned Dear ImGui sources under this directory and replace FetchContent with add_subdirectory().
