package com.example.mcpeclient;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public final class MainActivity extends Activity {
    static { System.loadLibrary("modmenu"); }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        TextView tv = new TextView(this);
        tv.setText("MCPE 26 native mod-menu template\\n\\nThis APK is a build/test host.\\nThe native overlay is implemented in libmodmenu.so.");
        tv.setTextSize(18f);
        tv.setPadding(32, 32, 32, 32);
        setContentView(tv);
    }
}
