#include "modmenu.h"

#include <EGL/egl.h>
#include <android/log.h>
#include <dlfcn.h>

// IMPORTANT:
// This file contains only a small renderer-hook abstraction. It does not
// contain Minecraft offsets, memory writes, anti-cheat bypasses, or an injector.
// A host/mod framework that is authorized to load this library can connect
// its renderer callback to HookedEglSwapBuffers().

namespace {
using SwapBuffersFn = EGLBoolean (*)(EGLDisplay, EGLSurface);
SwapBuffersFn g_original = nullptr;

bool g_setupAttempted = false;

void EnsureSetup() {
    if (g_setupAttempted) return;
    g_setupAttempted = true;
    modmenu::InitImGuiOnce();
}
}

extern "C" EGLBoolean HookedEglSwapBuffers(EGLDisplay display, EGLSurface surface) {
    EnsureSetup();
    modmenu::RenderFrame();

    // In a real host integration, g_original is supplied by the host's hook
    // mechanism. Keeping that plumbing outside this template avoids binding
    // the project to one injector/hook library or one Minecraft build.
    if (g_original) return g_original(display, surface);
    return eglSwapBuffers(display, surface);
}

extern "C" void ModMenuSetOriginalSwapBuffers(void* original) {
    g_original = reinterpret_cast<SwapBuffersFn>(original);
}

extern "C" void ModMenuSetVisible(bool visible) {
    modmenu::SetVisible(visible);
}
