#pragma once
#include <android/native_window.h>

namespace modmenu {
void InitImGuiOnce();
void SetAndroidWindow(ANativeWindow* window);
void RenderFrame();
void SetVisible(bool value);
bool IsVisible();
}
