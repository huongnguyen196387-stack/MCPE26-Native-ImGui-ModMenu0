#include "modmenu.h"

#include "imgui.h"
#include "imgui_impl_android.h"
#include "imgui_impl_opengl3.h"

#include <GLES3/gl3.h>
#include <android/log.h>
#include <android/native_window.h>
#include <atomic>

namespace {
std::atomic_bool g_visible{true};
std::atomic_bool g_initialized{false};
ANativeWindow* g_window = nullptr;

void Log(const char* msg) {
    __android_log_print(ANDROID_LOG_INFO, "MCPE26-ModMenu", "%s", msg);
}
}

namespace modmenu {

void InitImGuiOnce() {
    bool expected = false;
    if (!g_initialized.compare_exchange_strong(expected, true)) return;

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;

    ImGui::StyleColorsDark();
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowRounding = 10.0f;
    s.FrameRounding = 6.0f;
    s.ScrollbarRounding = 6.0f;

    // The renderer is OpenGL ES 3; Dear ImGui ships the Android + OpenGL3
    // backends used by this template.
    if (g_window) ImGui_ImplAndroid_Init(g_window);
    ImGui_ImplOpenGL3_Init("#version 300 es");
    Log("ImGui initialized");
}

void SetVisible(bool value) { g_visible.store(value, std::memory_order_relaxed); }
void SetAndroidWindow(ANativeWindow* window) { g_window = window; }
bool IsVisible() { return g_visible.load(std::memory_order_relaxed); }

void RenderFrame() {
    if (!g_initialized.load(std::memory_order_acquire)) return;
    if (!IsVisible()) return;

    ImGui_ImplOpenGL3_NewFrame();
    if (g_window) ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();

    static bool demo = false;
    static bool fpsCounter = true;
    static bool compact = false;

    ImGuiWindowFlags flags = ImGuiWindowFlags_NoCollapse;
    ImGui::SetNextWindowSize(ImVec2(420, 0), ImGuiCond_FirstUseEver);
    ImGui::Begin("MCPE 26 | Native Mod Menu", nullptr, flags);

    ImGui::TextUnformatted("Render-only foundation");
    ImGui::Separator();
    ImGui::Checkbox("FPS counter", &fpsCounter);
    ImGui::Checkbox("Compact layout", &compact);
    ImGui::Checkbox("ImGui demo", &demo);
    ImGui::Text("Frame time: %.2f ms", 1000.0f / ImGui::GetIO().Framerate);
    ImGui::Text("Display: %.0fx%.0f", ImGui::GetIO().DisplaySize.x, ImGui::GetIO().DisplaySize.y);

    if (ImGui::Button("Hide menu")) SetVisible(false);
    ImGui::SameLine();
    if (ImGui::Button("Reset layout")) ImGui::LoadIniSettingsFromMemory("", 0);

    ImGui::End();

    if (fpsCounter) {
        ImGui::SetNextWindowBgAlpha(0.45f);
        ImGui::Begin("##fps", nullptr,
            ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize |
            ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing |
            ImGuiWindowFlags_NoNav);
        ImGui::Text("FPS %.1f", ImGui::GetIO().Framerate);
        ImGui::End();
    }

    if (demo) ImGui::ShowDemoWindow(&demo);

    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}

} // namespace modmenu
