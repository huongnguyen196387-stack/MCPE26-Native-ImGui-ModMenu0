# MCPE 26 Native Mod Menu — C++ / ImGui template

A buildable Android NDK starter for a Bedrock-style native overlay architecture.

- C++20 + Android NDK
- arm64-v8a
- Dear ImGui Android backend + OpenGL ES 3 renderer
- Separate renderer-hook adapter
- Optional Dobby hook example (kept out of the default build)
- No hard-coded Minecraft addresses/offsets
- No anti-cheat bypass
- No memory patching
- No packet manipulation
- No injector included

## Versioning

Minecraft Bedrock 26.0 introduced the 2026 year-based version numbering on 10
February 2026. The release line subsequently moved through 26.1, 26.10,
26.20, 26.30 and later patches. A native address/class layout must therefore
be tied to the exact binary build and ABI, not just "26.x".

## Build

Open the project in Android Studio with an installed Android SDK/NDK. Gradle /
CMake fetches Dear ImGui during configuration.

```
./gradlew :app:assembleDebug
```

The APK is a host/test application. `libmodmenu.so` can also be reused by an
authorized native host/mod framework.

## Renderer contract

The core library exposes:

```cpp
modmenu::SetAndroidWindow(ANativeWindow* window);
modmenu::InitImGuiOnce();
modmenu::RenderFrame();
modmenu::SetVisible(bool);
```

`optional_dobby_renderer_hook.cpp.example` shows how a host could connect
`eglSwapBuffers` to the overlay using Dobby. It intentionally does not include
process injection, anti-cheat evasion, Minecraft memory edits, or version-
specific offsets.

## Input

Dear ImGui's official Android backend supports touch/keyboard/mouse events.
For an in-process Bedrock integration, the host should forward its native input
queue to `ImGui_ImplAndroid_HandleInputEvent()` and provide the matching
`ANativeWindow`. See Dear ImGui's Android + OpenGL3 example for the official
backend wiring.

## Next layer for a real mod

Keep Minecraft-specific logic separate from the UI:

```
src/
  ui/             # ImGui pages/widgets
  renderer/       # EGL/OpenGL renderer bridge
  input/          # host input bridge
  version/        # exact-build identifiers/signatures
  game_api/       # documented/authorized game-facing API
```

Avoid copying offsets from another 26.x patch. Re-resolve and validate every
version-specific native interface after an update.
